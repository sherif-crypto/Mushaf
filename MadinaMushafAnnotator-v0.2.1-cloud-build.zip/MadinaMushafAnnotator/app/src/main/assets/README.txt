No Quran PDF or Quran text is bundled.
The user selects a licensed 604-page Madina Mushaf PDF.
Exact structural metadata can be synced from Tanzil or imported as quran-data.xml.
Search text is imported by the user as UTF-8 plain text.
