package com.sherif.mushaf

import android.content.Context
import android.net.Uri
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

private data class MetadataSnapshot(
    val quarters: List<VerseRef>,
    val pages: List<PageStart>
)

class QuranMetadataRepository(private val context: Context) {
    companion object {
        const val OFFICIAL_URL = "https://tanzil.net/res/text/metadata/quran-data.xml"
    }

    private val file = File(context.filesDir, "quran-data.xml")
    @Volatile private var snapshot: MetadataSnapshot? = null

    init {
        loadLocal()
    }

    fun isReady(): Boolean = snapshot?.let { it.quarters.size == 240 && it.pages.size == 604 } == true

    fun statusText(): String = if (isReady()) "بيانات الفهرس الدقيقة جاهزة" else "تحتاج مزامنة بيانات الفهرس الدقيقة"

    fun pageForVerse(sura: Int, aya: Int): Int {
        val pages = snapshot?.pages ?: return QuranIndex.fallbackPageForVerse(sura, aya)
        var low = 0
        var high = pages.lastIndex
        var answer = 0
        while (low <= high) {
            val mid = (low + high) ushr 1
            val start = pages[mid]
            if (isAtOrBefore(start.sura, start.aya, sura, aya)) {
                answer = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return pages[answer].page.coerceIn(1, 604)
    }

    fun quarterEntries(): List<QuarterEntry> {
        val current = snapshot ?: return emptyList()
        return current.quarters.mapIndexed { index, ref ->
            QuarterEntry(index + 1, ref.sura, ref.aya, pageForVerse(ref.sura, ref.aya))
        }
    }

    fun pageForQuarter(index: Int): Int? = quarterEntries().getOrNull(index - 1)?.page

    suspend fun syncFromOfficial(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val tmp = File(context.cacheDir, "quran-data-download.xml")
            val connection = (URL(OFFICIAL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MadinaMushafAnnotator/0.2")
            }
            try {
                if (connection.responseCode !in 200..299) {
                    error("HTTP ${connection.responseCode}")
                }
                connection.inputStream.use { input ->
                    FileOutputStream(tmp).use { output -> input.copyTo(output) }
                }
                val parsed = FileInputStream(tmp).use(::parse)
                validate(parsed)
                tmp.copyTo(file, overwrite = true)
                snapshot = parsed
            } finally {
                connection.disconnect()
                tmp.delete()
            }
        }
    }

    suspend fun importFrom(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val tmp = File(context.cacheDir, "quran-data-import.xml")
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tmp).use { output -> input.copyTo(output) }
                } ?: error("تعذر فتح الملف")
                val parsed = FileInputStream(tmp).use(::parse)
                validate(parsed)
                tmp.copyTo(file, overwrite = true)
                snapshot = parsed
            } finally {
                tmp.delete()
            }
        }
    }

    private fun loadLocal() {
        if (!file.exists()) return
        snapshot = runCatching { FileInputStream(file).use(::parse).also(::validate) }.getOrNull()
    }

    private fun validate(data: MetadataSnapshot) {
        require(data.quarters.size == 240) { "عدد الأرباع غير صحيح: ${data.quarters.size}" }
        require(data.pages.size == 604) { "عدد الصفحات غير صحيح: ${data.pages.size}" }
    }

    private fun parse(input: java.io.InputStream): MetadataSnapshot {
        val parser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(input, "UTF-8")
        }
        val quarters = mutableListOf<VerseRef>()
        val pages = mutableListOf<PageStart>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "quarter" -> quarters += VerseRef(
                        parser.getAttributeValue(null, "sura").toInt(),
                        parser.getAttributeValue(null, "aya").toInt()
                    )
                    "page" -> pages += PageStart(
                        page = parser.getAttributeValue(null, "index").toInt(),
                        sura = parser.getAttributeValue(null, "sura").toInt(),
                        aya = parser.getAttributeValue(null, "aya").toInt()
                    )
                }
            }
            event = parser.next()
        }
        return MetadataSnapshot(
            quarters = quarters.toList(),
            pages = pages.sortedBy { it.page }
        )
    }


    private fun isAtOrBefore(s1: Int, a1: Int, s2: Int, a2: Int): Boolean =
        s1 < s2 || (s1 == s2 && a1 <= a2)
}
