package com.sherif.mushaf

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class AnnotationStore(private val context: Context) {
    private val dir = File(context.filesDir, "annotations").apply { mkdirs() }
    private val legacyPrefs = context.getSharedPreferences("ink_store", Context.MODE_PRIVATE)

    @Synchronized
    fun load(page: Int): List<InkStroke> {
        val file = pageFile(page)
        if (!file.exists()) migrateLegacyPage(page, file)
        if (!file.exists()) return emptyList()
        return parse(file.readText(Charsets.UTF_8))
    }

    @Synchronized
    fun save(page: Int, strokes: List<InkStroke>) {
        val file = pageFile(page)
        if (strokes.isEmpty()) {
            file.delete()
            return
        }
        val tmp = File(file.parentFile, "${file.name}.tmp")
        tmp.writeText(serialize(strokes), Charsets.UTF_8)
        if (!tmp.renameTo(file)) {
            file.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8)
            tmp.delete()
        }
    }

    @Synchronized
    fun exportTo(output: OutputStream) {
        ZipOutputStream(output.buffered()).use { zip ->
            val manifest = JSONObject()
                .put("format", "madina-mushaf-annotations")
                .put("version", 1)
                .toString(2)
            zip.putNextEntry(ZipEntry("manifest.json"))
            zip.write(manifest.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            dir.listFiles()
                ?.filter { it.isFile && it.name.matches(Regex("page_\\d{3}\\.json")) }
                ?.sortedBy { it.name }
                ?.forEach { file ->
                    zip.putNextEntry(ZipEntry("annotations/${file.name}"))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
        }
    }

    @Synchronized
    fun importFrom(input: InputStream): Int {
        var imported = 0
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val name = entry.name.substringAfterLast('/')
                if (!entry.isDirectory && name.matches(Regex("page_\\d{3}\\.json"))) {
                    val pageNumber = name.removePrefix("page_").removeSuffix(".json").toIntOrNull()
                    if (pageNumber != null && pageNumber in 1..604) {
                        val raw = readEntryLimited(zip, maxBytes = 10 * 1024 * 1024).toString(Charsets.UTF_8)
                        if (parse(raw).isNotEmpty() || raw.contains("\"strokes\"")) {
                            File(dir, name).writeText(raw, Charsets.UTF_8)
                            imported++
                        }
                    }
                }
                zip.closeEntry()
            }
        }
        return imported
    }

    private fun readEntryLimited(zip: ZipInputStream, maxBytes: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val read = zip.read(buffer)
            if (read < 0) break
            total += read
            require(total <= maxBytes) { "ملف تخطيط أكبر من الحد المسموح" }
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }

    private fun pageFile(page: Int) = File(dir, "page_${page.coerceIn(1, 604).toString().padStart(3, '0')}.json")

    private fun migrateLegacyPage(page: Int, file: File) {
        val raw = legacyPrefs.getString("p_$page", null) ?: return
        val migrated = parseLegacy(raw)
        if (migrated.isNotEmpty()) {
            file.writeText(serialize(migrated), Charsets.UTF_8)
            legacyPrefs.edit().remove("p_$page").apply()
        }
    }

    private fun serialize(strokes: List<InkStroke>): String {
        val arr = JSONArray()
        strokes.forEach { stroke ->
            val points = JSONArray()
            stroke.points.forEach { point ->
                points.put(JSONArray().put(point.x.toDouble()).put(point.y.toDouble()))
            }
            arr.put(
                JSONObject()
                    .put("color", stroke.color)
                    .put("width", stroke.width.toDouble())
                    .put("alpha", stroke.alpha.toDouble())
                    .put("points", points)
            )
        }
        return JSONObject().put("version", 1).put("strokes", arr).toString()
    }

    private fun parse(raw: String): List<InkStroke> = runCatching {
        val root = JSONObject(raw)
        val arr = root.getJSONArray("strokes")
        buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val pts = obj.getJSONArray("points")
                val points = buildList {
                    for (j in 0 until pts.length()) {
                        val p = pts.getJSONArray(j)
                        add(StrokePoint(p.getDouble(0).toFloat(), p.getDouble(1).toFloat()))
                    }
                }
                if (points.size >= 2) {
                    add(
                        InkStroke(
                            color = obj.getInt("color"),
                            width = obj.getDouble("width").toFloat(),
                            alpha = obj.getDouble("alpha").toFloat(),
                            points = points
                        )
                    )
                }
            }
        }
    }.getOrDefault(emptyList())

    private fun parseLegacy(raw: String): List<InkStroke> = runCatching {
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val pts = obj.getJSONArray("pts")
                val points = buildList {
                    for (j in 0 until pts.length()) {
                        val p = pts.getJSONArray(j)
                        add(StrokePoint(p.getDouble(0).toFloat(), p.getDouble(1).toFloat()))
                    }
                }
                if (points.size >= 2) {
                    add(
                        InkStroke(
                            obj.getInt("c"),
                            obj.getDouble("w").toFloat(),
                            obj.getDouble("a").toFloat(),
                            points
                        )
                    )
                }
            }
        }
    }.getOrDefault(emptyList())
}
