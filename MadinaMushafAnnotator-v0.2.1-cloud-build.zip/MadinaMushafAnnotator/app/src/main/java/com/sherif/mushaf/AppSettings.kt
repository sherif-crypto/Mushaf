package com.sherif.mushaf

import android.content.Context
import android.graphics.Color
import android.net.Uri

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    var pdfUri: Uri?
        get() = prefs.getString("pdf_uri", null)?.let(Uri::parse)
        set(value) { prefs.edit().putString("pdf_uri", value?.toString()).apply() }

    var pageOffset: Int
        get() = prefs.getInt("pdf_page_offset", 0)
        set(value) { prefs.edit().putInt("pdf_page_offset", value.coerceIn(0, 50)).apply() }

    var lastPage: Int
        get() = prefs.getInt("last_page", 1).coerceIn(1, 604)
        set(value) { prefs.edit().putInt("last_page", value.coerceIn(1, 604)).apply() }

    var penWidth: Float
        get() = prefs.getFloat("pen_width", 4.5f).coerceIn(2f, 10f)
        set(value) { prefs.edit().putFloat("pen_width", value.coerceIn(2f, 10f)).apply() }

    var highlighterWidth: Float
        get() = prefs.getFloat("highlighter_width", 22f).coerceIn(12f, 40f)
        set(value) { prefs.edit().putFloat("highlighter_width", value.coerceIn(12f, 40f)).apply() }

    var inkColor: Int
        get() = prefs.getInt("ink_color", Color.rgb(244, 190, 35))
        set(value) { prefs.edit().putInt("ink_color", value).apply() }

    var inkTool: InkTool
        get() = runCatching { InkTool.valueOf(prefs.getString("ink_tool", InkTool.HIGHLIGHTER.name)!!) }
            .getOrDefault(InkTool.HIGHLIGHTER)
        set(value) { prefs.edit().putString("ink_tool", value.name).apply() }
}
