package com.sherif.mushaf

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF315B4A),
                    background = Color(0xFFFAF7F0),
                    surface = Color(0xFFFFFCF6)
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MushafApp()
                }
            }
        }
    }
}

enum class Panel { NONE, INDEX, SEARCH, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MushafApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val renderer = remember { PdfPageRenderer(context) }
    val annotations = remember { AnnotationStore(context) }
    val settings = remember { AppSettings(context) }
    val metadata = remember { QuranMetadataRepository(context) }
    val searcher = remember { QuranTextSearch(context) }
    val snackbar = remember { SnackbarHostState() }

    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfPageCount by remember { mutableIntStateOf(0) }
    var pageOffset by remember { mutableIntStateOf(settings.pageOffset) }
    var page by remember { mutableIntStateOf(settings.lastPage) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var renderBusy by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var strokes by remember { mutableStateOf(emptyList<InkStroke>()) }
    var redoStack by remember { mutableStateOf(emptyList<InkStroke>()) }
    var tool by remember { mutableStateOf(settings.inkTool) }
    var inkColor by remember { mutableIntStateOf(settings.inkColor) }
    var penWidth by remember { mutableFloatStateOf(settings.penWidth) }
    var highlighterWidth by remember { mutableFloatStateOf(settings.highlighterWidth) }
    var resetZoomSignal by remember { mutableIntStateOf(0) }
    var metadataVersion by remember { mutableIntStateOf(0) }
    var searchVersion by remember { mutableIntStateOf(0) }
    var metadataBusy by remember { mutableStateOf(false) }
    var clearConfirm by remember { mutableStateOf(false) }
    var goToPageDialog by remember { mutableStateOf(false) }

    val pageCount = (pdfPageCount - pageOffset).coerceIn(0, 604)

    fun showMessage(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    fun goToPage(target: Int) {
        if (pageCount <= 0) return
        page = target.coerceIn(1, pageCount)
        settings.lastPage = page
        redoStack = emptyList()
        resetZoomSignal++
    }

    fun openPdf(uri: Uri, persistPermission: Boolean) {
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    if (persistPermission) {
                        runCatching {
                            context.contentResolver.takePersistableUriPermission(
                                uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                    }
                    renderer.open(uri)
                    renderer.pageCount
                }
            }
            result.onSuccess { count ->
                pdfUri = uri
                pdfPageCount = count
                settings.pdfUri = uri
                val available = (count - pageOffset).coerceIn(0, 604)
                if (available > 0) goToPage(settings.lastPage.coerceAtMost(available))
                showMessage("تم فتح المصحف: $count صفحة PDF")
            }.onFailure {
                withContext(Dispatchers.IO) { renderer.close() }
                pdfUri = null
                pdfPageCount = 0
                bitmap = null
                showMessage("تعذر فتح ملف المصحف: ${it.message ?: "خطأ غير معروف"}")
            }
        }
    }

    fun syncMetadata(showResult: Boolean = true) {
        if (metadataBusy) return
        metadataBusy = true
        scope.launch {
            val result = metadata.syncFromOfficial()
            metadataBusy = false
            if (result.isSuccess) {
                metadataVersion++
                if (showResult) showMessage("تمت مزامنة السور والأجزاء والأرباع والصفحات بدقة")
            } else if (showResult) {
                showMessage("تعذرت المزامنة. يمكنك استيراد quran-data.xml يدويًا من الإعدادات")
            }
        }
    }

    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openPdf(uri, persistPermission = true)
    }

    val textPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val count = withContext(Dispatchers.IO) { searcher.importText(uri) }
                if (count == 6236) {
                    searchVersion++
                    showMessage("تم تجهيز البحث في 6236 آية")
                } else {
                    showMessage("الملف غير صالح: يجب أن يحتوي 6236 آية كاملة")
                }
                panel = Panel.SEARCH
            }
        }
    }

    val metadataPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            metadataBusy = true
            scope.launch {
                val result = metadata.importFrom(uri)
                metadataBusy = false
                if (result.isSuccess) {
                    metadataVersion++
                    showMessage("تم استيراد بيانات الفهرس الدقيقة")
                } else {
                    showMessage("ملف metadata غير صالح أو غير مكتمل")
                }
            }
        }
    }

    val backupExporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use(annotations::exportTo)
                            ?: error("تعذر إنشاء الملف")
                    }
                }
                showMessage(if (result.isSuccess) "تم تصدير نسخة احتياطية للتخطيطات" else "فشل تصدير النسخة الاحتياطية")
            }
        }
    }

    val backupImporter = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openInputStream(uri)?.use(annotations::importFrom)
                            ?: error("تعذر فتح الملف")
                    }
                }
                result.onSuccess { count ->
                    strokes = annotations.load(page)
                    showMessage("تم استيراد تخطيطات $count صفحة")
                }.onFailure {
                    showMessage("ملف النسخة الاحتياطية غير صالح")
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        settings.pdfUri?.let { openPdf(it, persistPermission = false) }
        if (!metadata.isReady()) syncMetadata(showResult = false)
    }

    LaunchedEffect(page) {
        strokes = withContext(Dispatchers.IO) { annotations.load(page) }
        redoStack = emptyList()
    }

    LaunchedEffect(pdfUri, page, pageOffset, pdfPageCount) {
        val uri = pdfUri ?: return@LaunchedEffect
        if (pageCount <= 0) return@LaunchedEffect
        val pdfIndex = page - 1 + pageOffset
        if (pdfIndex !in 0 until pdfPageCount) return@LaunchedEffect
        renderBusy = true
        try {
            bitmap = withContext(Dispatchers.IO) { renderer.render(pdfIndex) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            bitmap = null
            showMessage("تعذر عرض الصفحة $page: ${e.message ?: "خطأ غير معروف"}")
        } finally {
            renderBusy = false
        }
    }

    DisposableEffect(Unit) {
        onDispose { renderer.close() }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (pdfUri == null) "مصحف المدينة بالقلم" else "مصحف المدينة — صفحة $page"
                    )
                },
                actions = {
                    TextButton(onClick = { panel = Panel.INDEX }) { Text("الفهرس") }
                    TextButton(onClick = { panel = Panel.SEARCH }) { Text("بحث") }
                    TextButton(onClick = { panel = Panel.SETTINGS }) { Text("إعدادات") }
                }
            )
        },
        bottomBar = {
            if (pdfUri != null && pageCount > 0) {
                BottomAppBar {
                    TextButton(onClick = { goToPage(page - 1) }, enabled = page > 1) { Text("السابق") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { goToPageDialog = true }) {
                        Text("$page / $pageCount")
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { goToPage(page + 1) }, enabled = page < pageCount) { Text("التالي") }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (pdfUri == null) {
                SetupScreen(
                    metadataReady = metadata.isReady(),
                    metadataBusy = metadataBusy,
                    onPickPdf = { pdfPicker.launch(arrayOf("application/pdf")) },
                    onSyncMetadata = { syncMetadata() },
                    onImportSearchText = { textPicker.launch(arrayOf("text/plain", "text/*")) }
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    ToolToolbar(
                        tool = tool,
                        color = inkColor,
                        undoEnabled = strokes.isNotEmpty(),
                        redoEnabled = redoStack.isNotEmpty(),
                        onTool = {
                            tool = it
                            settings.inkTool = it
                        },
                        onColor = {
                            inkColor = it
                            settings.inkColor = it
                        },
                        onUndo = {
                            strokes.lastOrNull()?.let { removed ->
                                strokes = strokes.dropLast(1)
                                redoStack = redoStack + removed
                                annotations.save(page, strokes)
                            }
                        },
                        onRedo = {
                            redoStack.lastOrNull()?.let { restored ->
                                redoStack = redoStack.dropLast(1)
                                strokes = strokes + restored
                                annotations.save(page, strokes)
                            }
                        },
                        onClear = { clearConfirm = true },
                        onResetZoom = { resetZoomSignal++ }
                    )

                    Box(Modifier.fillMaxSize().background(Color(0xFFE9E5DC))) {
                        val currentBitmap = bitmap
                        if (currentBitmap != null) {
                            ZoomableMushafPage(
                                page = page,
                                bitmap = currentBitmap,
                                strokes = strokes,
                                tool = tool,
                                color = inkColor,
                                width = if (tool == InkTool.HIGHLIGHTER) highlighterWidth else penWidth,
                                alpha = if (tool == InkTool.HIGHLIGHTER) 0.33f else 0.92f,
                                resetZoomSignal = resetZoomSignal,
                                onStrokeFinished = { stroke ->
                                    strokes = strokes + stroke
                                    redoStack = emptyList()
                                    annotations.save(page, strokes)
                                },
                                onErasePreview = { updated ->
                                    strokes = updated
                                    redoStack = emptyList()
                                },
                                onEraseFinished = { updated ->
                                    strokes = updated
                                    annotations.save(page, updated)
                                }
                            )
                        }
                        if (renderBusy || currentBitmap == null) {
                            CircularProgressIndicator(Modifier.align(Alignment.Center))
                        }
                    }
                }
            }

            if (panel == Panel.INDEX) {
                ModalBottomSheet(onDismissRequest = { panel = Panel.NONE }) {
                    IndexPanel(
                        metadataReady = metadata.isReady(),
                        quarters = metadata.quarterEntries(),
                        metadataBusy = metadataBusy,
                        onSyncMetadata = { syncMetadata() },
                        onGo = {
                            panel = Panel.NONE
                            goToPage(it)
                        }
                    )
                }
            }

            if (panel == Panel.SEARCH) {
                ModalBottomSheet(onDismissRequest = { panel = Panel.NONE }) {
                    SearchPanel(
                        searcher = searcher,
                        metadata = metadata,
                        metadataVersion = metadataVersion,
                        searchVersion = searchVersion,
                        onImport = { textPicker.launch(arrayOf("text/plain", "text/*")) },
                        onGo = {
                            panel = Panel.NONE
                            goToPage(it)
                        }
                    )
                }
            }

            if (panel == Panel.SETTINGS) {
                ModalBottomSheet(onDismissRequest = { panel = Panel.NONE }) {
                    SettingsPanel(
                        pageOffset = pageOffset,
                        pdfPageCount = pdfPageCount,
                        metadataReady = metadata.isReady(),
                        metadataBusy = metadataBusy,
                        searchReady = searcher.isReady(),
                        searchVerseCount = searcher.verseCount(),
                        penWidth = penWidth,
                        highlighterWidth = highlighterWidth,
                        onPageOffsetChange = { newOffset ->
                            pageOffset = newOffset
                            settings.pageOffset = newOffset
                            val available = (pdfPageCount - newOffset).coerceIn(0, 604)
                            if (available > 0 && page > available) goToPage(available)
                            resetZoomSignal++
                        },
                        onPenWidthChange = {
                            penWidth = it
                            settings.penWidth = it
                        },
                        onHighlighterWidthChange = {
                            highlighterWidth = it
                            settings.highlighterWidth = it
                        },
                        onChangePdf = { pdfPicker.launch(arrayOf("application/pdf")) },
                        onSyncMetadata = { syncMetadata() },
                        onImportMetadata = { metadataPicker.launch(arrayOf("application/xml", "text/xml", "text/plain")) },
                        onImportSearchText = { textPicker.launch(arrayOf("text/plain", "text/*")) },
                        onExportBackup = { backupExporter.launch("mushaf-annotations.zip") },
                        onImportBackup = { backupImporter.launch(arrayOf("application/zip", "application/octet-stream")) }
                    )
                }
            }
        }
    }

    if (clearConfirm) {
        AlertDialog(
            onDismissRequest = { clearConfirm = false },
            title = { Text("مسح تخطيطات الصفحة؟") },
            text = { Text("سيتم حذف كل الخطوط والتظليل في الصفحة $page فقط.") },
            confirmButton = {
                TextButton(onClick = {
                    clearConfirm = false
                    redoStack = emptyList()
                    strokes = emptyList()
                    annotations.save(page, emptyList())
                }) { Text("مسح") }
            },
            dismissButton = { TextButton(onClick = { clearConfirm = false }) { Text("إلغاء") } }
        )
    }

    if (goToPageDialog) {
        GoToPageDialog(
            currentPage = page,
            maxPage = pageCount.coerceAtLeast(1),
            onDismiss = { goToPageDialog = false },
            onGo = {
                goToPageDialog = false
                goToPage(it)
            }
        )
    }
}

@Composable
private fun SetupScreen(
    metadataReady: Boolean,
    metadataBusy: Boolean,
    onPickPdf: () -> Unit,
    onSyncMetadata: () -> Unit,
    onImportSearchText: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("مصحف المدينة بالقلم", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(10.dp))
        Text(
            "اختر ملف PDF لمصحف المدينة 604 صفحات. سيحفظ التطبيق الملف وآخر صفحة وتخطيطات الـS Pen.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onPickPdf) { Text("اختيار المصحف PDF") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onImportSearchText) { Text("استيراد نص القرآن للبحث") }
        Spacer(Modifier.height(18.dp))
        Text(if (metadataReady) "✓ الفهرس الدقيق جاهز" else "الفهرس الدقيق يحتاج مزامنة")
        if (!metadataReady) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onSyncMetadata, enabled = !metadataBusy) {
                Text(if (metadataBusy) "جارٍ المزامنة..." else "مزامنة الفهرس الدقيق")
            }
        }
    }
}

@Composable
private fun ToolToolbar(
    tool: InkTool,
    color: Int,
    undoEnabled: Boolean,
    redoEnabled: Boolean,
    onTool: (InkTool) -> Unit,
    onColor: (Int) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onClear: () -> Unit,
    onResetZoom: () -> Unit
) {
    val palette = listOf(
        AndroidColor.rgb(244, 190, 35),
        AndroidColor.rgb(89, 180, 103),
        AndroidColor.rgb(82, 153, 232),
        AndroidColor.rgb(230, 111, 156),
        AndroidColor.rgb(240, 130, 55)
    )
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(selected = tool == InkTool.PEN, onClick = { onTool(InkTool.PEN) }, label = { Text("قلم") })
            FilterChip(selected = tool == InkTool.HIGHLIGHTER, onClick = { onTool(InkTool.HIGHLIGHTER) }, label = { Text("تظليل") })
            FilterChip(selected = tool == InkTool.ERASER, onClick = { onTool(InkTool.ERASER) }, label = { Text("ممحاة") })
            TextButton(onClick = onUndo, enabled = undoEnabled) { Text("تراجع") }
            TextButton(onClick = onRedo, enabled = redoEnabled) { Text("إعادة") }
            TextButton(onClick = onResetZoom) { Text("1×") }
            TextButton(onClick = onClear, enabled = undoEnabled) { Text("مسح الصفحة") }
        }
        if (tool != InkTool.ERASER) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                palette.forEach { item ->
                    Box(
                        Modifier
                            .padding(horizontal = 7.dp)
                            .size(if (item == color) 27.dp else 22.dp)
                            .clip(CircleShape)
                            .background(Color(item))
                            .clickable { onColor(item) }
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text("S Pen يرسم • الإصبع يكبّر ويحرك", style = MaterialTheme.typography.labelSmall)
            }
        }
        HorizontalDivider()
    }
}

@Composable
private fun ZoomableMushafPage(
    page: Int,
    bitmap: Bitmap,
    strokes: List<InkStroke>,
    tool: InkTool,
    color: Int,
    width: Float,
    alpha: Float,
    resetZoomSignal: Int,
    onStrokeFinished: (InkStroke) -> Unit,
    onErasePreview: (List<InkStroke>) -> Unit,
    onEraseFinished: (List<InkStroke>) -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxSize().clipToBounds()) {
        val density = LocalDensity.current
        val viewportWidth = with(density) { maxWidth.toPx() }
        val viewportHeight = with(density) { maxHeight.toPx() }
        val imageAspect = bitmap.width.toFloat() / bitmap.height.toFloat()
        val viewportAspect = viewportWidth / viewportHeight.coerceAtLeast(1f)
        val baseWidth: Float
        val baseHeight: Float
        if (imageAspect > viewportAspect) {
            baseWidth = viewportWidth
            baseHeight = viewportWidth / imageAspect
        } else {
            baseHeight = viewportHeight
            baseWidth = viewportHeight * imageAspect
        }
        val baseLeft = (viewportWidth - baseWidth) / 2f
        val baseTop = (viewportHeight - baseHeight) / 2f

        var scale by remember(page) { mutableFloatStateOf(1f) }
        var panOffset by remember(page) { mutableStateOf(Offset.Zero) }

        LaunchedEffect(page, resetZoomSignal) {
            scale = 1f
            panOffset = Offset.Zero
        }

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(page, baseWidth, baseHeight) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        val oldScale = scale
                        val newScale = (oldScale * zoom).coerceIn(1f, 5f)
                        val ratio = newScale / oldScale
                        val proposed = Offset(
                            x = centroid.x - baseLeft - ratio * (centroid.x - baseLeft - panOffset.x) + pan.x,
                            y = centroid.y - baseTop - ratio * (centroid.y - baseTop - panOffset.y) + pan.y
                        )
                        scale = newScale
                        panOffset = clampPan(
                            proposed,
                            newScale,
                            baseLeft,
                            baseTop,
                            baseWidth,
                            baseHeight,
                            viewportWidth,
                            viewportHeight
                        )
                    }
                }
        ) {
            Box(
                Modifier
                    .offset { IntOffset(baseLeft.roundToInt(), baseTop.roundToInt()) }
                    .width(with(density) { baseWidth.toDp() })
                    .height(with(density) { baseHeight.toDp() })
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = scale
                        scaleY = scale
                        translationX = panOffset.x
                        translationY = panOffset.y
                    }
                    .background(Color.White)
            ) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "صفحة المصحف $page",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
                StylusInkLayer(
                    strokes = strokes,
                    tool = tool,
                    color = color,
                    width = width,
                    alpha = alpha,
                    onStrokeFinished = onStrokeFinished,
                    onErasePreview = onErasePreview,
                    onEraseFinished = onEraseFinished
                )
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun StylusInkLayer(
    strokes: List<InkStroke>,
    tool: InkTool,
    color: Int,
    width: Float,
    alpha: Float,
    onStrokeFinished: (InkStroke) -> Unit,
    onErasePreview: (List<InkStroke>) -> Unit,
    onEraseFinished: (List<InkStroke>) -> Unit
) {
    var current by remember { mutableStateOf(emptyList<StrokePoint>()) }
    var layerSize by remember { mutableStateOf(IntSize.Zero) }
    var eraserWorking by remember { mutableStateOf<List<InkStroke>?>(null) }

    fun normalizedPoint(x: Float, y: Float): StrokePoint? {
        if (layerSize.width <= 0 || layerSize.height <= 0) return null
        if (x < 0f || y < 0f || x > layerSize.width || y > layerSize.height) return null
        return StrokePoint(x / layerSize.width.toFloat(), y / layerSize.height.toFloat())
    }

    fun eraseAt(x: Float, y: Float) {
        if (layerSize.width <= 0 || layerSize.height <= 0) return
        val base = eraserWorking ?: strokes
        val updated = base.filterNot { stroke ->
            strokeTouches(stroke, x, y, layerSize.width.toFloat(), layerSize.height.toFloat(), 22f)
        }
        eraserWorking = updated
        onErasePreview(updated)
    }

    Canvas(
        Modifier
            .fillMaxSize()
            .onSizeChanged { layerSize = it }
            .pointerInteropFilter { event ->
                val pointerIndex = event.actionIndex.coerceAtLeast(0)
                val toolType = event.getToolType(pointerIndex)
                val isStylus = toolType == MotionEvent.TOOL_TYPE_STYLUS || toolType == MotionEvent.TOOL_TYPE_ERASER
                if (!isStylus) return@pointerInteropFilter false

                val buttonEraser = event.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY != 0
                val erasing = tool == InkTool.ERASER || toolType == MotionEvent.TOOL_TYPE_ERASER || buttonEraser

                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        if (erasing) {
                            eraserWorking = strokes
                            eraseAt(event.x, event.y)
                        } else {
                            current = normalizedPoint(event.x, event.y)?.let(::listOf) ?: emptyList()
                        }
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (erasing) {
                            for (h in 0 until event.historySize) eraseAt(event.getHistoricalX(0, h), event.getHistoricalY(0, h))
                            eraseAt(event.x, event.y)
                        } else {
                            val additions = buildList {
                                for (h in 0 until event.historySize) {
                                    normalizedPoint(event.getHistoricalX(0, h), event.getHistoricalY(0, h))?.let(::add)
                                }
                                normalizedPoint(event.x, event.y)?.let(::add)
                            }
                            if (additions.isNotEmpty()) current = current + additions
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (erasing) {
                            val final = eraserWorking ?: strokes
                            onEraseFinished(final)
                            eraserWorking = null
                        } else {
                            normalizedPoint(event.x, event.y)?.let { current = current + it }
                            if (current.size >= 2) onStrokeFinished(InkStroke(color, width, alpha, current))
                            current = emptyList()
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        if (eraserWorking != null) onEraseFinished(eraserWorking ?: strokes)
                        eraserWorking = null
                        current = emptyList()
                    }
                }
                true
            }
    ) {
        fun drawStroke(stroke: InkStroke) {
            if (stroke.points.size < 2) return
            val path = Path()
            path.moveTo(stroke.points.first().x * size.width, stroke.points.first().y * size.height)
            stroke.points.drop(1).forEach { point -> path.lineTo(point.x * size.width, point.y * size.height) }
            drawPath(
                path = path,
                color = Color(stroke.color).copy(alpha = stroke.alpha),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke.width, cap = StrokeCap.Round)
            )
        }

        strokes.forEach(::drawStroke)
        if (current.size >= 2) drawStroke(InkStroke(color, width, alpha, current))
    }
}

private fun clampPan(
    proposed: Offset,
    scale: Float,
    baseLeft: Float,
    baseTop: Float,
    baseWidth: Float,
    baseHeight: Float,
    viewportWidth: Float,
    viewportHeight: Float
): Offset {
    fun clampAxis(value: Float, baseStart: Float, baseSize: Float, viewport: Float): Float {
        val effective = baseSize * scale
        if (effective <= viewport) return 0f
        val min = viewport - effective - baseStart
        val max = -baseStart
        return value.coerceIn(min, max)
    }
    return Offset(
        clampAxis(proposed.x, baseLeft, baseWidth, viewportWidth),
        clampAxis(proposed.y, baseTop, baseHeight, viewportHeight)
    )
}

private fun strokeTouches(
    stroke: InkStroke,
    x: Float,
    y: Float,
    width: Float,
    height: Float,
    radius: Float
): Boolean {
    if (stroke.points.isEmpty()) return false
    val threshold = radius + stroke.width / 2f
    return stroke.points.zipWithNext().any { (a, b) ->
        val ax = a.x * width
        val ay = a.y * height
        val bx = b.x * width
        val by = b.y * height
        pointToSegmentDistance(x, y, ax, ay, bx, by) <= threshold
    }
}

private fun pointToSegmentDistance(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
    val dx = bx - ax
    val dy = by - ay
    if (dx == 0f && dy == 0f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)).coerceIn(0f, 1f)
    val cx = ax + t * dx
    val cy = ay + t * dy
    return hypot(px - cx, py - cy)
}

@Composable
private fun IndexPanel(
    metadataReady: Boolean,
    quarters: List<QuarterEntry>,
    metadataBusy: Boolean,
    onSyncMetadata: () -> Unit,
    onGo: (Int) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var suraFilter by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding()) {
        Text("الفهرس والانتقال", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab) {
            listOf("السور", "الأجزاء", "الأحزاب والأرباع").forEachIndexed { index, title ->
                Tab(selected = tab == index, onClick = { tab = index }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> {
                OutlinedTextField(
                    value = suraFilter,
                    onValueChange = { suraFilter = it },
                    label = { Text("اسم السورة") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                val visible = QuranIndex.suras.filter { suraFilter.isBlank() || it.name.contains(suraFilter.trim()) }
                LazyColumn(Modifier.heightIn(max = 590.dp)) {
                    items(visible, key = { it.number }) { sura ->
                        ListItem(
                            headlineContent = { Text("${sura.number}. ${sura.name}") },
                            supportingContent = { Text("صفحة ${sura.page} • ${sura.ayas} آية") },
                            modifier = Modifier.clickable { onGo(sura.page) }
                        )
                    }
                }
            }
            1 -> LazyColumn(Modifier.heightIn(max = 610.dp)) {
                items((1..30).toList()) { juz ->
                    val page = QuranIndex.pageForJuz(juz)
                    ListItem(
                        headlineContent = { Text("الجزء $juz") },
                        supportingContent = { Text("صفحة $page") },
                        modifier = Modifier.clickable { onGo(page) }
                    )
                }
            }
            else -> {
                if (!metadataReady) {
                    Column(
                        Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("يلزم تنزيل metadata الموثقة مرة واحدة لعرض 240 ربعًا بمواضعها الدقيقة.", textAlign = TextAlign.Center)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onSyncMetadata, enabled = !metadataBusy) {
                            Text(if (metadataBusy) "جارٍ المزامنة..." else "مزامنة الآن")
                        }
                    }
                } else {
                    LazyColumn(Modifier.heightIn(max = 610.dp)) {
                        items(quarters, key = { it.index }) { quarter ->
                            val hizb = (quarter.index - 1) / 4 + 1
                            val within = (quarter.index - 1) % 4 + 1
                            val quarterName = listOf("الأول", "الثاني", "الثالث", "الرابع")[within - 1]
                            ListItem(
                                headlineContent = { Text("الحزب $hizb — الربع $quarterName") },
                                supportingContent = {
                                    Text("${QuranIndex.suraName(quarter.sura)} ${quarter.aya} • صفحة ${quarter.page}")
                                },
                                modifier = Modifier.clickable { onGo(quarter.page) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchPanel(
    searcher: QuranTextSearch,
    metadata: QuranMetadataRepository,
    metadataVersion: Int,
    searchVersion: Int,
    onImport: () -> Unit,
    onGo: (Int) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf(emptyList<SearchHit>()) }
    var searching by remember { mutableStateOf(false) }

    LaunchedEffect(query, metadataVersion, searchVersion) {
        if (query.trim().length < 2) {
            hits = emptyList()
            return@LaunchedEffect
        }
        searching = true
        delay(180)
        hits = withContext(Dispatchers.Default) { searcher.search(query, metadata) }
        searching = false
    }

    Column(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding()) {
        Text("البحث في القرآن", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        if (!searcher.isReady()) {
            Text("استورد نص قرآن UTF-8 كاملًا (6236 آية). يدعم Tanzil plain text، أو صيغة sura|aya|text.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = onImport) { Text("استيراد نص القرآن") }
        } else {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("كلمة أو جزء من آية") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (metadata.isReady()) "الانتقال من نتائج البحث إلى الصفحة الدقيقة" else "الصفحات تقريبية حتى تتم مزامنة metadata",
                style = MaterialTheme.typography.labelSmall
            )
            if (searching) CircularProgressIndicator(Modifier.padding(12.dp).size(28.dp))
            LazyColumn(Modifier.heightIn(max = 570.dp)) {
                items(hits) { hit ->
                    ListItem(
                        headlineContent = { Text(hit.text, maxLines = 3) },
                        supportingContent = {
                            Text("سورة ${QuranIndex.suraName(hit.sura)}، آية ${hit.aya} • صفحة ${hit.page}${if (hit.exactPage) "" else " تقريبية"}")
                        },
                        modifier = Modifier.clickable { onGo(hit.page) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    pageOffset: Int,
    pdfPageCount: Int,
    metadataReady: Boolean,
    metadataBusy: Boolean,
    searchReady: Boolean,
    searchVerseCount: Int,
    penWidth: Float,
    highlighterWidth: Float,
    onPageOffsetChange: (Int) -> Unit,
    onPenWidthChange: (Float) -> Unit,
    onHighlighterWidthChange: (Float) -> Unit,
    onChangePdf: () -> Unit,
    onSyncMetadata: () -> Unit,
    onImportMetadata: () -> Unit,
    onImportSearchText: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit
) {
    LazyColumn(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding()) {
        item {
            Text("الإعدادات", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            Text("ملف المصحف", style = MaterialTheme.typography.titleMedium)
            Text("عدد صفحات PDF الحالي: $pdfPageCount")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onChangePdf) { Text("تغيير ملف المصحف") }
            Spacer(Modifier.height(12.dp))
            Text("صفحات زائدة قبل صفحة المصحف رقم 1: $pageOffset")
            Slider(
                value = pageOffset.toFloat(),
                onValueChange = { onPageOffsetChange(it.roundToInt()) },
                valueRange = 0f..20f,
                steps = 19
            )
            Text("استخدمها إذا كان ملف PDF يحتوي غلافًا أو صفحات تمهيدية.", style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))

            Text("القلم والتظليل", style = MaterialTheme.typography.titleMedium)
            Text("سمك القلم: ${"%.1f".format(penWidth)}")
            Slider(value = penWidth, onValueChange = onPenWidthChange, valueRange = 2f..10f)
            Text("سمك التظليل: ${highlighterWidth.roundToInt()}")
            Slider(value = highlighterWidth, onValueChange = onHighlighterWidthChange, valueRange = 12f..40f)
            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))

            Text("بيانات الفهرس", style = MaterialTheme.typography.titleMedium)
            Text(if (metadataReady) "✓ البيانات الدقيقة جاهزة: 604 صفحات و240 ربعًا" else "غير جاهزة بعد")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onSyncMetadata, enabled = !metadataBusy) {
                Text(if (metadataBusy) "جارٍ المزامنة..." else "مزامنة من Tanzil")
            }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = onImportMetadata) { Text("استيراد quran-data.xml يدويًا") }
            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))

            Text("البحث", style = MaterialTheme.typography.titleMedium)
            Text(if (searchReady) "✓ جاهز للبحث في $searchVerseCount آية" else "لم يتم استيراد نص البحث")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onImportSearchText) { Text("استيراد/تغيير نص القرآن للبحث") }
            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))

            Text("نسخة احتياطية", style = MaterialTheme.typography.titleMedium)
            Text("صدّر كل تخطيطاتك إلى ZIP أو استوردها على هاتف آخر.")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onExportBackup) { Text("تصدير") }
                OutlinedButton(onClick = onImportBackup) { Text("استيراد") }
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "بيانات الفهرس: Tanzil Quran Metadata. التطبيق لا يغيّر نص القرآن، وملف المصحف يختاره المستخدم.",
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun GoToPageDialog(
    currentPage: Int,
    maxPage: Int,
    onDismiss: () -> Unit,
    onGo: (Int) -> Unit
) {
    var value by remember { mutableStateOf(currentPage.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الانتقال إلى صفحة") },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it.filter(Char::isDigit).take(3) },
                label = { Text("1 إلى $maxPage") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.widthIn(min = 220.dp)
            )
        },
        confirmButton = {
            TextButton(
                onClick = { value.toIntOrNull()?.coerceIn(1, maxPage)?.let(onGo) },
                enabled = value.toIntOrNull() != null
            ) { Text("انتقال") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
