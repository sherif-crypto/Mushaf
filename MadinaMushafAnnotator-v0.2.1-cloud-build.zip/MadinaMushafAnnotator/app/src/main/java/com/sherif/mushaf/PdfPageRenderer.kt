package com.sherif.mushaf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache

class PdfPageRenderer(private val context: Context) : AutoCloseable {
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null

    private val cache = object : LruCache<Int, Bitmap>(48 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.allocationByteCount / 1024
    }

    val pageCount: Int
        @Synchronized get() = renderer?.pageCount ?: 0

    @Synchronized
    fun open(uri: Uri) {
        close()
        descriptor = context.contentResolver.openFileDescriptor(uri, "r")
            ?: error("تعذر فتح ملف PDF")
        renderer = PdfRenderer(descriptor!!)
    }

    @Synchronized
    fun render(pageIndex: Int, maxWidth: Int = 1800): Bitmap? {
        cache.get(pageIndex)?.let { return it }
        val currentRenderer = renderer ?: return null
        if (pageIndex !in 0 until currentRenderer.pageCount) return null

        val page = currentRenderer.openPage(pageIndex)
        return try {
            val scale = (maxWidth.toFloat() / page.width.toFloat()).coerceIn(0.25f, 4f)
            val width = (page.width * scale).toInt().coerceAtLeast(1)
            val height = (page.height * scale).toInt().coerceAtLeast(1)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            cache.put(pageIndex, bitmap)
            bitmap
        } finally {
            page.close()
        }
    }

    @Synchronized
    override fun close() {
        cache.evictAll()
        renderer?.close()
        renderer = null
        descriptor?.close()
        descriptor = null
    }
}
