package com.sherif.mushaf

data class SuraEntry(
    val number: Int,
    val name: String,
    val page: Int,
    val ayas: Int
)

data class VerseRef(val sura: Int, val aya: Int)

data class PageStart(val page: Int, val sura: Int, val aya: Int)

data class QuarterEntry(
    val index: Int,
    val sura: Int,
    val aya: Int,
    val page: Int
)

data class StrokePoint(val x: Float, val y: Float)

data class InkStroke(
    val color: Int,
    val width: Float,
    val alpha: Float,
    val points: List<StrokePoint>
)

data class SearchHit(
    val sura: Int,
    val aya: Int,
    val text: String,
    val page: Int,
    val exactPage: Boolean
)

enum class InkTool { PEN, HIGHLIGHTER, ERASER }
