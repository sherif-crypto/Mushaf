package com.sherif.mushaf

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.text.Normalizer

private data class SearchVerse(
    val sura: Int,
    val aya: Int,
    val text: String,
    val normalized: String
)

class QuranTextSearch(private val context: Context) {
    companion object {
        private val EXPECTED_VERSE_COUNT = QuranIndex.ayaCounts.sum()
    }

    private val sourceFile = File(context.filesDir, "quran-search-source.txt")
    @Volatile private var cache: List<SearchVerse>? = null

    fun importText(uri: Uri): Int {
        val tmp = File(context.cacheDir, "quran-search-import.txt")
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp).use { output -> input.copyTo(output) }
            } ?: return 0

            val parsed = parseFile(tmp)
            if (parsed.size != EXPECTED_VERSE_COUNT) {
                tmp.delete()
                return 0
            }

            tmp.copyTo(sourceFile, overwrite = true)
            tmp.delete()
            cache = parsed
            parsed.size
        }.getOrElse {
            tmp.delete()
            0
        }
    }

    fun isReady(): Boolean = ensureLoaded().size == EXPECTED_VERSE_COUNT

    fun verseCount(): Int = ensureLoaded().size

    fun search(query: String, metadata: QuranMetadataRepository, limit: Int = 100): List<SearchHit> {
        val q = normalize(query)
        if (q.length < 2) return emptyList()
        val exact = metadata.isReady()
        return ensureLoaded().asSequence()
            .filter { it.normalized.contains(q) }
            .take(limit)
            .map { verse ->
                SearchHit(
                    sura = verse.sura,
                    aya = verse.aya,
                    text = verse.text,
                    page = metadata.pageForVerse(verse.sura, verse.aya),
                    exactPage = exact
                )
            }
            .toList()
    }

    @Synchronized
    private fun ensureLoaded(): List<SearchVerse> {
        cache?.let { return it }
        if (!sourceFile.exists()) return emptyList()
        val parsed = parseFile(sourceFile)
        cache = parsed
        return parsed
    }

    private fun parseFile(file: File): List<SearchVerse> {
        val dataLines = file.readLines(Charsets.UTF_8)
            .map { it.removePrefix("\uFEFF") }
            .filter { it.isNotBlank() && !it.trimStart().startsWith("#") }

        val structured = dataLines.mapNotNull(::parseStructuredLine)
        val result = when {
            structured.size == EXPECTED_VERSE_COUNT && hasValidSequence(structured) -> structured
            dataLines.size == EXPECTED_VERSE_COUNT -> mapPlainLines(dataLines)
            else -> emptyList()
        }
        return result.takeIf { it.size == EXPECTED_VERSE_COUNT } ?: emptyList()
    }

    private fun hasValidSequence(verses: List<SearchVerse>): Boolean {
        var index = 0
        for (sura in 1..114) {
            for (aya in 1..QuranIndex.ayaCounts[sura - 1]) {
                val verse = verses.getOrNull(index++) ?: return false
                if (verse.sura != sura || verse.aya != aya) return false
            }
        }
        return index == verses.size
    }

    private fun parseStructuredLine(line: String): SearchVerse? {
        val parts = line.split('|')
        val parsed = when {
            parts.size >= 3 -> Triple(
                parts[0].trim().toIntOrNull() ?: return null,
                parts[1].trim().toIntOrNull() ?: return null,
                parts.drop(2).joinToString("|")
            )
            parts.size == 2 && parts[0].contains(':') -> {
                val key = parts[0].split(':')
                Triple(
                    key.getOrNull(0)?.trim()?.toIntOrNull() ?: return null,
                    key.getOrNull(1)?.trim()?.toIntOrNull() ?: return null,
                    parts[1]
                )
            }
            else -> return null
        }
        if (parsed.first !in 1..114 || parsed.second !in 1..QuranIndex.ayaCounts[parsed.first - 1]) return null
        return SearchVerse(parsed.first, parsed.second, parsed.third, normalize(parsed.third))
    }

    private fun mapPlainLines(lines: List<String>): List<SearchVerse> {
        if (lines.size != EXPECTED_VERSE_COUNT) return emptyList()
        val result = ArrayList<SearchVerse>(EXPECTED_VERSE_COUNT)
        var lineIndex = 0
        for (sura in 1..114) {
            val count = QuranIndex.ayaCounts[sura - 1]
            for (aya in 1..count) {
                val text = lines[lineIndex++]
                result += SearchVerse(sura, aya, text, normalize(text))
            }
        }
        return result
    }

    private fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]"), "")
        .replace("ٱ", "ا")
        .replace("أ", "ا")
        .replace("إ", "ا")
        .replace("آ", "ا")
        .replace("ى", "ي")
        .replace("ؤ", "و")
        .replace("ئ", "ي")
        .replace(Regex("\\s+"), " ")
        .trim()
}
